﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class boardGround : MonoBehaviour
{

    public player[,] checkers = new player[15, 15];
    public GameObject blackchecker;
    public GameObject brownchecker;
   
    private void Start()
    {
        GenBoard();
    }
    private void GenBoard()
    {
        // GEN black team
        for (int y = 0; y < 3; y++)
        {
            for (int x = 0; x < 5; x++)
            {
                // Generate piece
                GenChecker(x, y);
            }
        }
    }
    private void GenChecker(int x, int y)

    { 
        GameObject go = Instantiate(blackchecker) as GameObject;
        go.transform.SetParent(transform);
        player p = go.GetComponent<player>();
        checkers[x ,y] = p;
        
    }
    
}
    
